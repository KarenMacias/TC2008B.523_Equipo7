from mesa.visualization.ModularVisualization import ModularServer

from .model import BoidFlockers
from .SimpleContinuousModule import SimpleCanvas


#def boid_draw(agent):
    #return {"Shape": "rect", "w":0.03, "h":0.05, "Filled": "true", "Color": "Blue"}

def boid_draw(agent):
    portrayal = {"Filled": "False"}
    
    if agent.typeOf == 1 and agent.orientation == 0:
        portrayal["Shape"] = "rect"
        portrayal["Filled"] = "false"
        portrayal["Color"] = "gray"
        portrayal["Layer"] = 0
        portrayal["w"] = 1
        portrayal["h"] = 0.1
    elif agent.typeOf == 1 and agent.orientation == 1:
        portrayal["Filled"] = "false"
        portrayal["Shape"] = "rect"
        portrayal["Color"] = "gray"
        portrayal["Layer"] = 0
        portrayal["w"] = 0.1
        portrayal["h"] = 1
    elif agent.typeOf == 0 and (agent.pos[0] == 20.0 or agent.pos[0] == 30.0) :
        portrayal["Shape"] = "rect"
        portrayal["Color"] = "blue"
        portrayal["Layer"] = 1
        portrayal["w"] = 0.03
        portrayal["h"] = 0.05
    elif agent.typeOf == 0 and (agent.pos[1] == 20.0 or agent.pos[1] == 30.0):
        portrayal["Shape"] = "rect"
        portrayal["Color"] = "blue"
        portrayal["Layer"] = 1
        portrayal["w"] = 0.05
        portrayal["h"] = 0.03
    elif agent.typeOf == 2 and agent.pos[1] == 20 and agent.color == 0:
        portrayal["Shape"] = "rect"
        portrayal["Color"] = "green"
        portrayal["Layer"] = 2
        portrayal["w"] = 0.10
        portrayal["h"] = 0.03
    elif agent.typeOf == 2 and agent.pos[0] == 20 and agent.color == 0:
        portrayal["Shape"] = "rect"
        portrayal["Color"] = "green"
        portrayal["Layer"] = 2
        portrayal["w"] = 0.03
        portrayal["h"] = 0.10
    elif agent.typeOf == 2 and agent.pos[1] == 30 and agent.color == 0:
        portrayal["Shape"] = "rect"
        portrayal["Color"] = "green"
        portrayal["Layer"] = 2
        portrayal["w"] = 0.10
        portrayal["h"] = 0.03
    elif agent.typeOf == 2 and agent.pos[0] == 30 and agent.color == 0:
        portrayal["Shape"] = "rect"
        portrayal["Color"] = "green"
        portrayal["Layer"] = 2
        portrayal["w"] = 0.03
        portrayal["h"] = 0.10
    elif agent.typeOf == 2 and agent.pos[1] == 20 and agent.color == 1:
        portrayal["Shape"] = "rect"
        portrayal["Color"] = "red"
        portrayal["Layer"] = 2
        portrayal["w"] = 0.10
        portrayal["h"] = 0.03
    elif agent.typeOf == 2 and agent.pos[0] == 20 and agent.color == 1:
        portrayal["Shape"] = "rect"
        portrayal["Color"] = "red"
        portrayal["Layer"] = 2
        portrayal["w"] = 0.03
        portrayal["h"] = 0.10
    elif agent.typeOf == 2 and agent.pos[1] == 30 and agent.color == 1:
        portrayal["Shape"] = "rect"
        portrayal["Color"] = "red"
        portrayal["Layer"] = 2
        portrayal["w"] = 0.10
        portrayal["h"] = 0.03
    elif agent.typeOf == 2 and agent.pos[0] == 30 and agent.color == 1:
        portrayal["Shape"] = "rect"
        portrayal["Color"] = "red"
        portrayal["Layer"] = 2
        portrayal["w"] = 0.03
        portrayal["h"] = 0.10
    elif agent.typeOf == 2 and agent.pos[1] == 20 and agent.color == 2:
        portrayal["Shape"] = "rect"
        portrayal["Color"] = "yellow"
        portrayal["Layer"] = 2
        portrayal["w"] = 0.10
        portrayal["h"] = 0.03
    elif agent.typeOf == 2 and agent.pos[0] == 20 and agent.color == 2:
        portrayal["Shape"] = "rect"
        portrayal["Color"] = "yellow"
        portrayal["Layer"] = 2
        portrayal["w"] = 0.03
        portrayal["h"] = 0.10
    elif agent.typeOf == 2 and agent.pos[1] == 30 and agent.color == 2:
        portrayal["Shape"] = "rect"
        portrayal["Color"] = "yellow"
        portrayal["Layer"] = 2
        portrayal["w"] = 0.10
        portrayal["h"] = 0.03
    elif agent.typeOf == 2 and agent.pos[0] == 30 and agent.color == 2:
        portrayal["Shape"] = "rect"
        portrayal["Color"] = "yellow"
        portrayal["Layer"] = 2
        portrayal["w"] = 0.03
        portrayal["h"] = 0.10
    elif agent.typeOf == 2 and agent.pos[1] == 20 and agent.color == 3:
        portrayal["Shape"] = "rect"
        portrayal["Color"] = "yellow"
        portrayal["Layer"] = 2
        portrayal["w"] = 0.10
        portrayal["h"] = 0.03
    elif agent.typeOf == 2 and agent.pos[0] == 20 and agent.color == 3:
        portrayal["Shape"] = "rect"
        portrayal["Color"] = "yellow"
        portrayal["Layer"] = 2
        portrayal["w"] = 0.03
        portrayal["h"] = 0.10
    elif agent.typeOf == 2 and agent.pos[1] == 30 and agent.color == 3:
        portrayal["Shape"] = "rect"
        portrayal["Color"] = "yellow"
        portrayal["Layer"] = 2
        portrayal["w"] = 0.10
        portrayal["h"] = 0.03
    elif agent.typeOf == 2 and agent.pos[0] == 30 and agent.color == 3:
        portrayal["Shape"] = "rect"
        portrayal["Color"] = "yellow"
        portrayal["Layer"] = 2
        portrayal["w"] = 0.03
        portrayal["h"] = 0.10
    return portrayal


boid_canvas = SimpleCanvas(boid_draw, 500, 500)
model_params = {
    "population": 4,
    "width": 50,
    "height": 50,
    "speed": 5,
    "vision": 10,
    "separation": 1,
}

server = ModularServer(BoidFlockers, [boid_canvas], "Boids", model_params)
