import numpy as np
import random

from mesa import Agent

class TrafficLight(Agent):
    def __init__(self,unique_id,model,pos,color):
        """
        Create a traffic light 

        Args:
            unique_id: Unique agent identifyer.
            pos: Starting position
        """
        super().__init__(unique_id, model)
        self.pos = np.array(pos)
        self.typeOf = 2
        self.color = color

class PathV(Agent):
    def __init__(self,unique_id,model,pos):
        """
        Create a vertical path 

        Args:
            unique_id: Unique agent identifyer.
            pos: Starting position
        """
        super().__init__(unique_id, model)
        self.pos = np.array(pos)
        self.typeOf = 1
        self.orientation = 1

class PathH(Agent):
    def __init__(self,unique_id,model,pos):
        """
        Create a horizontal path

        Args:
            unique_id: Unique agent identifyer.
            pos: Starting position
        """
        super().__init__(unique_id, model)
        self.pos = np.array(pos)
        self.typeOf = 1
        self.orientation = 0
        

class Boid(Agent):
    """
    A Boid-style flocker agent.

    The agent follows three behaviors to flock:
        - Cohesion: steering towards neighboring agents.
        - Separation: avoiding getting too close to any other agent.
        - Alignment: try to fly in the same direction as the neighbors.

    Boids have a vision that defines the radius in which they look for their
    neighbors to flock with. Their speed (a scalar) and velocity (a vector)
    define their movement. Separation is their desired minimum distance from
    any other Boid.
    """
    
    def __init__(self,unique_id,model,pos,speed,velocity,vision,separation,cohere=0.025,separate=0.25,match=0.04):
        """
        Create a new Boid flocker agent.

        Args:
            unique_id: Unique agent identifyer.
            pos: Starting position
            speed: Distance to move per step.
            heading: numpy vector for the Boid's direction of movement.
            vision: Radius to look around for nearby Boids.
            separation: Minimum distance to maintain from other Boids.
            cohere: the relative importance of matching neighbors' positions
            separate: the relative importance of avoiding close neighbors
            match: the relative importance of matching neighbors' headings

        """
        super().__init__(unique_id, model)
        self.pos = np.array(pos)
        self.speed = speed
        self.velocity = velocity
        self.vision = vision
        self.separation = separation
        self.cohere_factor = cohere
        self.separate_factor = separate
        self.match_factor = match
        self.typeOf = 0

    def cohere(self, neighbors):
        """
        Return the vector toward the center of mass of the local neighbors.
        """
        cohere = np.zeros(2)
        if neighbors:
            for neighbor in neighbors:
                cohere += self.model.space.get_heading(self.pos, neighbor.pos)
            cohere /= len(neighbors)
        return cohere

    def separate(self, neighbors):
        """
        Return a vector away from any neighbors closer than separation dist.
        """
        me = self.pos
        them = (n.pos for n in neighbors)
        separation_vector = np.zeros(2)
        for other in them:
            if self.model.space.get_distance(me, other) < self.separation:
                separation_vector -= self.model.space.get_heading(me, other)
        return separation_vector

    def match_heading(self, neighbors):
        """
        Return a vector of the neighbors' average heading.
        """
        match_vector = np.zeros(2)
        if neighbors:
            for neighbor in neighbors:
                match_vector += neighbor.velocity
            match_vector /= len(neighbors)
        return match_vector

    def step(self):
        """
        Get the Boid's neighbors, compute the new vector, and move accordingly.
        """

        neighborsBefore = self.model.space.get_neighbors(self.pos, self.vision, False)
        neighbors = []
        neighborsTraffic = []
        print("velocityantes", self.velocity)
        suma = self.cohere(neighbors) * self.cohere_factor + self.separate(neighbors) * self.separate_factor + self.match_heading(neighbors) * self.match_factor/ 2
        print("+=valor", suma)
        self.velocity += (
                self.cohere(neighbors) * self.cohere_factor
                + self.separate(neighbors) * self.separate_factor
                + self.match_heading(neighbors) * self.match_factor
            ) / 2
        
        valor = np.linalg.norm(self.velocity)
        print(valor, "valor")
        
        #Revisamos si donde se acerca es un semáforo
        for i in neighborsBefore:
            print("typeofN", i.typeOf)
            if i.typeOf == 2:
                neighborsTraffic.append(i)
        print(neighborsTraffic, "neighbors")
        self.velocity /= np.linalg.norm(self.velocity)
        random_number = random.randint(1,5)
        print("randomNum", random_number)
        self.velocity /= random_number
        new_pos = self.pos + self.velocity * self.speed
        self.model.space.move_agent(self, new_pos)
        
        #Si es un semáforo
        if len(neighborsTraffic) > 0:
            #tenemos que revisar la posición, la del agente, el color que tiene, disminuimos, aumentamos la velocidad etc etc
            for i in neighborsTraffic:
                print(i.color, "color")
                #Si es verde cambia a amarillo 3
                if(i.color == 0 and i.pos[0] == self.pos[0]):
                    i.color = 3
                    '''
                    self.velocity /= np.linalg.norm(self.velocity)
                    self.velocity /= 7
                    new_pos = self.pos + self.velocity * self.speed
                    self.model.space.move_agent(self, new_pos)
                    '''
                    #Comienza a disminuir la velocidad en un rango menor
                #De verde a amarillo 3
                elif(i.color == 0 and i.pos[1] == self.pos[1]):
                    i.color = 3
                    print("entr´po posicion y")
                    '''
                    self.velocity /= np.linalg.norm(self.velocity)
                    self.velocity /= 7
                    new_pos = self.pos + self.velocity * self.speed
                    self.model.space.move_agent(self, new_pos)
                    '''
                #Si esta en rojo cambia a amarillo 2
                elif(i.color == 1 and i.pos[0] == self.pos[0]):
                    i.color = 2
                    '''
                    self.velocity /= np.linalg.norm(self.velocity)
                    self.velocity /= 7
                    new_pos = self.pos + self.velocity * self.speed
                    self.model.space.move_agent(self, new_pos)
                    '''
                    #La velocidad comienza a aumentar en un rango menor
                #De rojo a amarillo 2
                elif(i.color == 1 and i.pos[1] == self.pos[1]):
                    i.color = 2
                    print("entr´po posicion y")
                    '''
                    self.velocity /= np.linalg.norm(self.velocity)
                    self.velocity /= 7
                    new_pos = self.pos + self.velocity * self.speed
                    self.model.space.move_agent(self, new_pos)
                    '''
                #Si el valor es amarillo 2
                elif(i.color == 2 and i.pos[0] == self.pos[0]):
                    #Cambio a verde
                    i.color = 0
                    '''
                    self.velocity /= np.linalg.norm(self.velocity)
                    self.velocity /= 3
                    new_pos = self.pos + self.velocity * self.speed
                    self.model.space.move_agent(self, new_pos)
                    '''
                #Amarillo 2 a verde
                elif(i.color == 2 and i.pos[1] == self.pos[1]):
                    #Cambio a verde
                    i.color = 0
                    print("entr´po posicion y")
                    '''
                    self.velocity /= np.linalg.norm(self.velocity)
                    self.velocity /= 2
                    new_pos = self.pos + self.velocity * self.speed
                    self.model.space.move_agent(self, new_pos)
                    '''
                #Amarillo 3 a rojo
                elif(i.color == 3 and i.pos[1] == self.pos[1]):
                    i.color = 1
                    '''
+                    self.velocity /= np.linalg.norm(self.velocity)
                    self.velocity /= 2
                    new_pos = self.pos + self.velocity * self.speed
                    self.model.space.move_agent(self, new_pos)
                    '''
                #De amarillo 3 lo cambio a rojo
                elif(i.color == 3 and i.pos[1] == self.pos[1]):
                    i.color = 1
                    print("entr´po posicion y")
                    '''
                    self.velocity /= np.linalg.norm(self.velocity)
                    self.velocity /= 2
                    new_pos = self.pos + self.velocity * self.speed
                    self.model.space.move_agent(self, new_pos)
        '''          '''
        else:
            self.velocity /= np.linalg.norm(self.velocity)
            random_number = random.randint(1,5)
            print("randomNum", random_number)
            self.velocity /= random_number
            new_pos = self.pos + self.velocity * self.speed
            self.model.space.move_agent(self, new_pos)
        '''
                
        
