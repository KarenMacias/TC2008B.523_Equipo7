"""
Flockers
=============================================================
A Mesa implementation of Craig Reynolds's Boids flocker model.
Uses numpy arrays to represent vectors.
"""

import numpy as np

from mesa import Model
from mesa.space import ContinuousSpace
from mesa.time import RandomActivation

from .boid import Boid
from .boid import PathH
from .boid import PathV
from .boid import TrafficLight


class BoidFlockers(Model):
    """
    Flocker model class. Handles agent creation, placement and scheduling.
    """

    def __init__(self,population=5,width=50,height=50,speed=1,vision=10,separation=2,cohere=0.025,separate=0.25,match=0.04):
        """
        Create a new Flockers model.

        Args:
            population: Number of Boids
            width, height: Size of the space.
            speed: How fast should the Boids move.
            vision: How far around should each Boid look for its neighbors
            separation: What's the minimum distance each Boid will attempt to
                    keep from any other
            cohere, separate, match: factors for the relative importance of
                    the three drives."""
        self.population = population
        self.vision = vision
        self.speed = speed
        self.separation = separation
        self.schedule = RandomActivation(self)
        self.space = ContinuousSpace(width, height, True)
        self.factors = dict(cohere=cohere, separate=separate, match=match)
        self.make_agents()
        self.running = True

    def make_agents(self):
        """
        Create self.population agents, with random positions and starting headings.
        """
        positionsx = [20.0, 1.0, 30.0, 1.0]
        positionsy = [1.0, 20.0, 1.0, 30.0]
        velocityx = [0,1,0,1]
        velocityy = [1,0,1,0]
        for i in range(self.population):
            #x = self.random.random() * self.space.x_max
            #y = self.random.random() * self.space.y_max
            x = positionsx[i]
            y = positionsy[i]
            pos = np.array((x, y))
            #velocity = np.random.random(2) * 2 - 1
            velocity = [velocityx[i], velocityy[i]]
            boid = Boid(i,self,pos,self.speed,velocity,self.vision,self.separation,**self.factors)
            self.space.place_agent(boid, pos)
            self.schedule.add(boid)
            
        """
        Create the paths
        """
        pos1 = np.array((25.0,25.0))
        path1 = PathH(100,self,pos1)
        pos2 = np.array((25.0,25.0))
        path2 = PathV(101,self,pos2)
        self.space.place_agent(path1, pos1)
        self.space.place_agent(path2, pos2)
        self.schedule.add(path1)
        self.schedule.add(path2)
        
        """
        Create the traffic lights
        """
        light1 = TrafficLight(102,self,np.array((25.0,20.0)),0) 
        light2 = TrafficLight(103,self,np.array((20.0,25.0)),1)
        light3 = TrafficLight(104,self,np.array((25.0,30.0)),0) 
        light4 = TrafficLight(105,self,np.array((30.0,25.0)),1)
        self.space.place_agent(light1, np.array((25.0,20.0)))
        self.space.place_agent(light2, np.array((20.0,25.0)))
        self.space.place_agent(light3, np.array((25.0,30.0)))
        self.space.place_agent(light4, np.array((30.0,25.0)))
        self.schedule.add(light1)
        self.schedule.add(light2)
        self.schedule.add(light3)
        self.schedule.add(light4)
        
        
    def step(self):
        self.schedule.step()
        #Arreglo de posiciones que recibe el servidor
        ps = []
        #Para cada step obtenemos las posiciones para unity
        for i in range(self.population):
            print(self.schedule.agents[i].pos)
            print("Typeof", self.schedule.agents[i].typeOf)
            xy = self.schedule.agents[i].pos
            #Guardamos la posición de [x, z, y]
            p = [xy[0], xy[1], 0]
            ps.append(p)
