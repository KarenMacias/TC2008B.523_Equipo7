from boid_flockers.server import server

server.launch()
